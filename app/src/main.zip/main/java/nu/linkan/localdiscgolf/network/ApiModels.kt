package nu.linkan.localdiscgolf.network

data class LoginRequest(
    val username: String,
    val password: String
)

data class LoginResponse(
    val access_token: String,
    val token_type: String,
    val user_id: Long,
    val username: String,
    val role: String,
    val must_change_password: Boolean
)

data class MeResponse(
    val id: Long,
    val username: String,
    val role: String,
    val is_active: Int,
    val must_change_password: Int
)

data class CourseApiResponse(
    val id: Long,
    val name: String,
    val is_active: Int,
    val hole_count: Int,
    val layout_count: Int
)

data class LayoutApiResponse(
    val id: Long,
    val course_id: Long,
    val course_name: String,
    val name: String,
    val description: String?,
    val is_active: Int,
    val hole_count: Int,
    val total_par: Int,
    val total_length_meters: Int
)

data class LayoutHoleApiResponse(
    val sequence_number: Int,
    val hole_id: Long,
    val hole_number: Int,
    val hole_name: String?,
    val hole_variant_id: Long?,
    val tee_name: String?,
    val basket_name: String?,
    val length_meters: Int,
    val par_value: Int
)

data class UserApiResponse(
    val id: Long,
    val username: String,
    val role: String,
    val is_active: Int
)

data class PlayerApiResponse(
    val id: Long,
    val name: String,
    val owner_user_id: Long?,
    val created_by_user_id: Long?,
    val is_guest: Int,
    val is_active: Int,
    val round_count: Int
)

data class ScoreablePlayerApiResponse(
    val id: Long,
    val name: String,
    val owner_user_id: Long?,
    val created_by_user_id: Long?,
    val is_guest: Int,
    val is_active: Int,
    val permission_level: String,
    val round_count: Int
)

data class UserPlayersResponse(
    val user: UserApiResponse,
    val own_player: PlayerApiResponse?,
    val guest_players: List<PlayerApiResponse>,
    val scoreable_players: List<ScoreablePlayerApiResponse>
)

data class PlayerRoundApiResponse(
    val id: Long,
    val course_name: String,
    val layout_name: String?,
    val started_at: String,
    val ended_at: String?,
    val status: String,
    val approval_required: Int,
    val approval_state: String,
    val total_throws: Int,
    val total_par: Int,
    val played_holes: Int,
    val layout_hole_count: Int,
    val player_count: Int
)

data class RoundDetailApiResponse(
    val id: Long,
    val course_id: Long,
    val course_name: String,
    val created_by_user_id: Long,
    val created_by_username: String,
    val started_at: String,
    val ended_at: String?,
    val status: String,
    val players: List<RoundDetailPlayerApiResponse>
)

data class RoundDetailPlayerApiResponse(
    val id: Long,
    val play_session_id: Long,
    val player_id: Long,
    val player_name: String,
    val layout_id: Long?,
    val layout_name: String?,
    val display_name_snapshot: String?,
    val start_order: Int,
    val added_by_user_id: Long,
    val added_by_username: String,
    val approval_required: Int,
    val approval_state: String,
    val approved_by_user_id: Long?,
    val approved_by_username: String?,
    val approved_at: String?,
    val holes: List<RoundDetailHoleApiResponse>
)

data class RoundDetailHoleApiResponse(
    val id: Long,
    val session_player_id: Long,
    val sequence_number: Int,
    val course_id: Long,
    val hole_id: Long,
    val hole_variant_id: Long?,
    val hole_number_snapshot: Int,
    val hole_name_snapshot: String?,
    val tee_name_snapshot: String?,
    val basket_name_snapshot: String?,
    val length_snapshot_meters: Int,
    val par_snapshot: Int,
    val throws_count: Int?,
    val is_completed: Int
)

data class CreateRoundPlayerApiRequest(
    val player_id: Long,
    val layout_id: Long
)

data class CreateRoundApiRequest(
    val course_id: Long,
    val started_at: String,
    val players: List<CreateRoundPlayerApiRequest>
)

data class CurrentRoundApiResponse(
    val round: CurrentRoundInfoApiResponse,
    val progress: CurrentRoundProgressApiResponse,
    val players: List<CurrentRoundPlayerApiResponse>,
    val summary_to_previous_hole: List<CurrentRoundSummaryApiResponse>,
    val current_hole: CurrentRoundHoleApiResponse
)

data class CurrentRoundInfoApiResponse(
    val id: Long,
    val course_id: Long,
    val course_name: String,
    val created_by_user_id: Long,
    val created_by_username: String,
    val started_at: String,
    val ended_at: String?,
    val status: String
)

data class CurrentRoundProgressApiResponse(
    val total_holes: Int,
    val completed_holes: Int,
    val current_sequence_number: Int,
    val is_finished_by_scores: Boolean
)

data class CurrentRoundPlayerApiResponse(
    val session_player_id: Long,
    val player_id: Long,
    val player_name: String,
    val layout_id: Long?,
    val layout_name: String?,
    val start_order: Int,
    val approval_required: Int,
    val approval_state: String
)

data class CurrentRoundSummaryApiResponse(
    val session_player_id: Long,
    val player_id: Long,
    val player_name: String,
    val start_order: Int,
    val total_throws: Int,
    val relative_to_par: Int,
    val played_holes: Int
)

data class CurrentRoundHoleApiResponse(
    val sequence_number: Int,
    val hole_id: Long,
    val hole_variant_id: Long?,
    val hole_number: Int,
    val hole_name: String?,
    val tee_name: String?,
    val basket_name: String?,
    val length_meters: Int,
    val par_value: Int,
    val scores: List<CurrentRoundHoleScoreApiResponse>
)

data class CurrentRoundHoleScoreApiResponse(
    val session_player_id: Long,
    val player_id: Long,
    val player_name: String,
    val start_order: Int,
    val throws_count: Int?,
    val is_completed: Boolean
)

data class UpdateHoleScoreApiRequest(
    val player_id: Long,
    val throws_count: Int?
)

data class UpdateHoleApiRequest(
    val scores: List<UpdateHoleScoreApiRequest>
)

data class CompleteRoundApiRequest(
    val ended_at: String
)

data class InProgressServerRoundApiResponse(
    val id: Long,
    val course_name: String,
    val layout_name: String?,
    val started_at: String,
    val status: String,
    val player_count: Int
)

data class PlayerLayoutStatsApiResponse(
    val course_id: Long,
    val course_name: String,
    val layout_id: Long,
    val layout_name: String,
    val total_par: Int,
    val hole_count: Int,
    val total_length_meters: Int,
    val round_count: Int,
    val personal_best_throws: Int,
    val personal_best_relative_to_par: Int,
    val average_throws: Double,
    val average_relative_to_par: Double,
    val last_10_average_throws: Double?,
    val last_10_average_relative_to_par: Double?
)

data class PlayerHoleStatsApiResponse(
    val course_id: Long,
    val course_name: String,
    val hole_id: Long,
    val hole_variant_id: Long?,
    val hole_number: Int,
    val hole_name: String?,
    val tee_name: String?,
    val basket_name: String?,
    val length_meters: Int,
    val par_value: Int,
    val played_count: Int,
    val personal_best_throws: Int,
    val streak: Int,
    val average_throws: Double,
    val last_10_average_throws: Double?,
    val birdie_or_better_count: Int,
    val par_count: Int,
    val bogey_count: Int,
    val double_bogey_count: Int,
    val triple_bogey_or_worse_count: Int
)